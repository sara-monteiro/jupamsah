<?php

const MYSQL_DB_HOST = "localhost";
const MYSQL_DB_PORT = "3306";
const MYSQL_DB_DATABASE = "jupamsah";
const MYSQL_DB_USERNAME = "root";
const MYSQL_DB_PASSWORD = "";


?>