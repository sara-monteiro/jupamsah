$(document).ready(function(){
    $('#loginForm').submit(function(event){
        event.preventDefault();
        
        var email = $('#email').val();
        var senha = $('#senha').val();
        
        if(email == '' || senha == '') {
            $('#mensagem').html('Por favor, preencha todos os campos.');
        } else {
            $.ajax({
                type: 'POST',
                url: 'login.php',
                data: $(this).serialize(),
                success: function(response){
                    if(response.trim() == 'success') {
                        window.location = 'dashboard.html';
                    } else {
                        $('#mensagem').html('Email ou senha incorretos.');
                    }
                }
            });
        }
    });
});