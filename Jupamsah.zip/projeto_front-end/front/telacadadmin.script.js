document.getElementById('cadastrar').addEventListener('click', function() {

    var nome = document.getElementById('nome').value; 
    var email = document.getElementById('email').value; 
    var cpf = document.getElementById('cpf').value;
    var matricula = document.getElementById('matricula').value;
    var cargo = document.getElementById('cargo').value;
    var localtrabalho = document.getElementById('localtrabalho').value;
    var senha = document.getElementById('senha').value;

    fazerRequisicao(1, undefined, nome, email, cpf, matricula, cargo, localtrabalho, senha);
    fazerRequisicao(2, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);

});

document.getElementById('listar').addEventListener('click', function(){
    fazerRequisicao(2, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
});

document.getElementById('atualizar').addEventListener('click', function(){
    var id = document.getElementById('id').value; 
    var nome = document.getElementById('nome').value; 
    var email = document.getElementById('email').value; 
    var cpf = document.getElementById('cpf').value;
    var matricula = document.getElementById('matricula').value;
    var cargo = document.getElementById('cargo').value;
    var localtrabalho = document.getElementById('localtrabalho').value;
    var senha = document.getElementById('senha').value;

    fazerRequisicao(3, id, nome, email, cpf, matricula, cargo, localtrabalho, senha);
    fazerRequisicao(2, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);

});

document.getElementById('deletar').addEventListener('click', function(){
    var id = document.getElementById('id').value;

    fazerRequisicao(4, id, undefined, undefined, undefined, undefined, undefined, undefined);
    fazerRequisicao(2, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
});

function fazerRequisicao(tipo, id, nome, email, cpf, matricula, cargo, localtrabalho, senha) {
    var url = `http://localhost/projeto_front-end/back/data/cadadmin.index.php?tipo=${tipo}`;

    if (id !== undefined){
        url += `&id=${id}`;
    }
    if (nome !== undefined){
        url += `&nome=${nome}`;
    }
    if (email !== undefined){
        url += `&email=${email}`;
    }
    if (cpf !== undefined){
        url += `&cpf=${cpf}`;
    }
    if (matricula !== undefined){
        url += `&matricula=${matricula}`;
    }
    if (cargo !== undefined){
        url += `&cargo=${cargo}`;
    }
    if (localtrabalho !== undefined){
        url += `&localtrabalho=${localtrabalho}`;
    }    
    if (senha !== undefined){
        url += `&senha=${senha}`;
    }

    console.log("URL da requisição:", url);

    fetch(url, {method: 'get'})
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro na requisição.');
        }
        return response.json();
    })
    .then(data => {
        console.log("Dados recebidos:", data);
        // Limpar a tabela antes de preencher
        var tableBody = document.querySelector('.table tbody');
        tableBody.innerHTML = '';

        // Preencher a tabela com os dados retornados
        data.forEach(item => {
            var newRow = tableBody.insertRow();
            newRow.innerHTML = `
                <td>${item.id}</td>
                <td>${item.nome}</td>
                <td>${item.email}</td>
                <td>${item.cpf}</td>
                <td>${item.matricula}</td>
                <td>${item.cargo}</td>
                <td>${item.localtrabalho}</td>
            `;
        });
    })
    .catch(error => {
        console.error('Erro:', error);
    });

    // Limpar os campos de entrada após a requisição
    document.getElementById('id').value = ""; 
    document.getElementById('nome').value = ""; 
    document.getElementById('email').value = ""; 
    document.getElementById('cpf').value = ""; 
    document.getElementById('matricula').value = ""; 
    document.getElementById('cargo').value = ""; 
    document.getElementById('localtrabalho').value = ""; 
    document.getElementById('senha').value = ""; 
}
